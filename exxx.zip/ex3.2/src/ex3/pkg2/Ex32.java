
package ex3.pkg2;

import java.util.Scanner;

public class Ex32 {

   
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        String linea;

        while (true) {
            System.out.print("Ingrese una línea de caracteres (o 'salir' para terminar): ");
            linea = entrada.nextLine();

            if (linea.equalsIgnoreCase("salir")) {
                System.out.println("¡Adiós!");
                break;
            }

            System.out.println("\nElija una opción:");
            System.out.println("1. Reemplazar vocales por la letra más común no vocal.");
            System.out.println("2. Invertir la línea de caracteres.");
            System.out.println("3. Salir.");
            System.out.print("Opción: ");
            int opcion = entrada.nextInt();
            entrada.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("La línea resultante es: " + reemplazarVocales(linea));
                    break;
                case 2:
                    System.out.println("La línea resultante es: " + invertirLinea(linea));
                    break;
                case 3:
                    System.out.println("¡Byee !");
                    return;
                default:
                    System.out.println("Opción inválida..... Intente de nuevo.");
            }
        }
    }

    public static boolean esVocal(char c) {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
               c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U';
    }

    public static String reemplazarVocales(String linea) {
        // Contar la frecuencia de cada letra no vocal.
        int[] frecuencia = new int[26];  // Suponemos que solo hay letras inglesas.
        for (int i = 0; i < linea.length(); i++) {
            char c = linea.charAt(i);
            if (!esVocal(c) && Character.isLetter(c)) {
                frecuencia[Character.toLowerCase(c) - 'a']++;
            }
        }

        // Encontrar la letra no vocal más común.
        char letraComun = ' ';
        int maxFrecuencia = -1;
        for (int i = 0; i < 26; i++) {
            char letra = (char) ('a' + i);
            if (frecuencia[i] > maxFrecuencia) {
                letraComun = letra;
                maxFrecuencia = frecuencia[i];
            }
        }

        // Reemplazar las vocales por la letra no vocal más común.
        StringBuilder sb = new StringBuilder(linea.length());//Objeto
        for (int i = 0; i < linea.length(); i++) {
            char c = linea.charAt(i);
            if (esVocal(c)) {
                sb.append(letraComun);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String invertirLinea(String linea) {
        StringBuilder sb = new StringBuilder(linea);
        sb.reverse();
        return sb.toString();
    }
        
        
        
}
        
